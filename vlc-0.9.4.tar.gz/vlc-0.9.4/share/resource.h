//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vlc_wince_rc.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_NIOUP                       3
#define IDI_NIOUP                       101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDM_FILE_EXIT                   40002
#define IDM_HELP_ABOUT                  40003
#define IDM_PLOP                        40004
#define ID_VIEW_PLAYLIST                40005
#define ID_VIEW_MESSAGES                40006
#define ID_SETTINGS_AUDIO               40007
#define ID_SETTINGS_SUBTITLES           40008
#define ID_SETTINGS                     40011
#define ID_FILE_OPENFILE                40012
#define ID_FILE_NETWORKSTREAM           40013

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
